# Poker Tournament Manager

A Java application for managing poker tournaments including player registration, table assignment, blind structures, and result export.

## Features
- Register and manage players
- Configure blind structure
- Track player chip counts and eliminations
- Export tournament results
