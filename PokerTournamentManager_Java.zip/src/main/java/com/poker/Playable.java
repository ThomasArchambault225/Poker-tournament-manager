package com.poker;

public interface Playable {
    void playHand();
}