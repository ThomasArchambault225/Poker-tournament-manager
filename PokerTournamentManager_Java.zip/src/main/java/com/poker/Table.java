package com.poker;

import java.util.List;

public class Table implements Playable {
    private List<Player> players;
    public void playHand() {}
}