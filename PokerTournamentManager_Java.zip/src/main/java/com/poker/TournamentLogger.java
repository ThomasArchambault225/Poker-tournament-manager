package com.poker;

public class TournamentLogger {
    public void writeLog() {}
    public void read() {}
}