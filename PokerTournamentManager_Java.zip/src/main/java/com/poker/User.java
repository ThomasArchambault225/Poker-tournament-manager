package com.poker;

public abstract class User {
    protected String name;
    protected int id;

    public String getName() { return name; }
    public int getId() { return id; }
}