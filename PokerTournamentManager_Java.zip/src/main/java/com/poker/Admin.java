package com.poker;

public class Admin extends User {

}