package com.poker;

public abstract class TournamentComponent {

}