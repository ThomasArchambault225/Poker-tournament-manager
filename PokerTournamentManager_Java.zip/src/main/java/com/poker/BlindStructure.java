package com.poker;

public class BlindStructure extends TournamentComponent {

}