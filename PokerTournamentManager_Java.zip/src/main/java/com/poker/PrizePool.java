package com.poker;

public class PrizePool extends TournamentComponent {

}